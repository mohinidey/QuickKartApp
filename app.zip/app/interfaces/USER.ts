export interface IUser {
  EmailId: string,
  UserPassword: string,
  RoleId: number,
  Gender: string,
  DateOfBirth: Date,
  Address: string
}
