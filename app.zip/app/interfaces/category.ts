export interface ICategory {
  CategoryId: number;
  CategoryName: string
}
