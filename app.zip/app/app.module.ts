import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { ViewProductsComponent } from './view-products/view-products.component';
import { LoginComponent } from './login/login.component';
import { HttpClientModule } from '@angular/common/http';
import { CommonlayoutComponent } from './commonlayout/commonlayout.component';
import { HomeComponent } from './home/home.component';
import { CustomerLayoutComponent } from './customer-layout/customer-layout.component';
import { RouterModule } from '@angular/router';
import { routes } from './app.routing';
import { PurchasedetailsComponent } from './purchasedetails/purchasedetails.component';
import { ViewCartComponent } from './view-cart/view-cart.component';
import { UpdateCartComponent } from './update-cart/update-cart.component';
import { ViewRatingComponent } from './view-rating/view-rating.component';
import { UpdateRatingComponent } from './update-rating/update-rating.component';
import { UpdateRatingsComponent } from './update-ratings/update-ratings.component';

@NgModule({
  declarations: [
    AppComponent,
    ViewProductsComponent,
    LoginComponent,
    CommonlayoutComponent,
    HomeComponent,
    CustomerLayoutComponent,
    PurchasedetailsComponent,
    ViewCartComponent,
    UpdateCartComponent,
    ViewRatingComponent,
    UpdateRatingComponent,
    UpdateRatingsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
