import { Component, OnInit } from '@angular/core';
import { IRating } from '../interfaces/rating';
import { ViewRatingService } from '../services/rating.service';
import { Router } from '@angular/router';
import { IProduct } from '../interfaces/product';

@Component({
  selector: 'app-view-rating',
  templateUrl: './view-rating.component.html',
  styleUrls: ['./view-rating.component.css']
})
export class ViewRatingComponent implements OnInit {

  ratingdetail: IRating[];
  userRole: string;
  customerlayout: boolean=false;
  commonlayout: boolean = false;
  emailId: string;
  userName: string;
  status: boolean = false;

  constructor(private ratingservice: ViewRatingService, private router: Router) {

    this.userRole = sessionStorage.getItem('userRole');
    this.userName = sessionStorage.getItem('userName');

    if (this.userRole == 'Customer')
      this.customerlayout = true;
    else
      this.commonlayout = true;
  }

  ngOnInit() {
    this.emailId = sessionStorage.getItem('userName');
    this.ratingservice.DisplayAllReviewDetailsByEmailId(this.emailId).subscribe(
      response => this.ratingdetail=response,
      error => { console.log("error occured in rating service");
      },
      () => { console.log("rating method occured successfully"); }
    );
  }

  insertrating(rates: IRating ) {

    if (this.userRole == null) {
      this.router.navigate(['/login']);
    }
    else {
      this.ratingservice.InsertRating(rates.ProductId, rates.ProductName, rates.ReviewRating, rates.ReviewComments).subscribe(
        response => {
          if (response)
            alert("rating added sucessfully.")
        },
        error => { console.log("error occured in rating service");
        },
        () => { console.log("rating method excuted successfully");}
      );
    }
  }

  updatereview(rate: IRating) {
    this.router.navigate(['/updateRatings', rate.ProductId, rate.ProductName]);
  }

  deleteReview(rate: IRating) {
    this.ratingservice.DeleteRating(rate.ProductName, this.emailId, rate.ProductId, rate.ReviewRating, rate.ReviewComments).subscribe(
      response => {
        this.status = response;
        if (this.status) {
          alert("Delete the review successfully")
          this.ngOnInit();
        }
      else
          alert("review could not be deleted...please try once again")
      },
      error => { console.log("There is some error in delete method of review "); },
      () => { console.log("Delete method had excuted successfully");}
    );
  }



}
